const express = require('express');
const app = express();
const path = require('path');
const router = express.Router();
const mongoose = require('mongoose')
app.use(express.static('public'))
const user = require('./modal/user');
mongoose.connect('mongodb://127.0.0.1:27017/myapp');
app.use(express.urlencoded({extended:true}))
app.use(express.json())
router.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/home.html'));
  //__dirname : It will resolve to your project folder.
});
 
router.get('/login',function(req,res){
  res.sendFile(path.join(__dirname+'/login.html'));
});
 
router.post('/login',function(req,res){
    let data = user.find({email:req.body.email})
    console.log(data)
    res.redirect('/');
  });
router.get('/register',function(req,res){
  res.sendFile(path.join(__dirname+'/register.html'));
});

router.post('/register',async function(req,res){
    console.log(req.body)
    let i =  await user.create({
        name:req.body.name,
        password:req.body.password,
        email:req.body.email,
    })
    console.log(i)
    res.sendFile(path.join(__dirname+'/home.html'));
  });
router.get('/contact',function(req,res){
    res.sendFile(path.join(__dirname+'/contact.html'));
  });
  router.get('/blog',function(req,res){
    res.sendFile(path.join(__dirname+'/blog.html'));
  });
  router.get('/resource',function(req,res){
    res.sendFile(path.join(__dirname+'/Resources.html'));
  });
//add the router
app.use('/', router);
app.listen(process.env.port || 3000);
 
console.log('Running at Port 3000');